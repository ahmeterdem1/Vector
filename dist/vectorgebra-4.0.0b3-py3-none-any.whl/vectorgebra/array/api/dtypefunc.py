
def astype():
    pass

def can_cast():
    pass

def finfo():
    pass

def iinfo():
    pass

def isdtype():
    pass

def result_type():
    pass
