"""
    This module contains more complex implementations for the Arrays
"""