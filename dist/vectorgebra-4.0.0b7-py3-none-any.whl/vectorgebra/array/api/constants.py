e = 2.718281828459045
inf = float("inf")
nan = float("nan")
newaxis = None
pi = 3.141592653589793
