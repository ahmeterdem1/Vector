
def abs():
    pass

def acos():
    pass

def acosh():
    pass

def add():
    pass

def asin():
    pass

def asinh():
    pass

def atan():
    pass

def atan2():
    pass

def atanh():
    pass

def bitwise_and():
    pass

def bitwise_left_shift():
    pass

def bitwise_invert():
    pass

def bitwise_or():
    pass

def bitwise_right_shift():
    pass

def bitwise_xor():
    pass

def ceil():
    pass

def clip():
    pass

def conj():
    pass

def copysign():
    pass

def cos():
    pass

def cosh():
    pass

def divide():
    pass

def equal():
    pass

def exp():
    pass

def expm1():
    pass

def floor():
    pass

def floor_divide():
    pass

def greater():
    pass

def greater_equal():
    pass

def hypot():
    pass

def imag():
    pass

def isfinite():
    pass

def isinf():
    pass

def isnan():
    pass

def less():
    pass

def less_equal():
    pass

def log():
    pass

def log1p():
    pass

def log2():
    pass

def log10():
    pass

def logaddexp():
    pass

def logical_and():
    pass

def logical_or():
    pass

def logical_xor():
    pass

def maximum():
    pass

def minimum():
    pass

def multiply():
    pass

def negative():
    pass

def not_equal():
    pass

def positive():
    pass

def pow():
    pass

def real():
    pass

def remainder():
    pass

def round():
    pass

def sign():
    pass

def signbit():
    pass

def sin():
    pass

def sinh():
    pass

def square():
    pass

def sqrt():
    pass

def subtract():
    pass

def tan():
    pass

def tanh():
    pass

def trunc():
    pass
