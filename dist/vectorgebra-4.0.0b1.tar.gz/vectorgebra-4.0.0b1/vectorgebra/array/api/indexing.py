
def take():
    pass
