"""
    Linear algebra extension of Array API referenced by: https://data-apis.org/array-api/latest/extensions/linear_algebra_functions.html
"""
