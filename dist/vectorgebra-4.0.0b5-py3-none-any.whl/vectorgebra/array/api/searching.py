from ..ndarray import Array

def argmax():
    pass

def argmin():
    pass

def nonzero():
    pass

def searchsorted():
    pass

def where():
    pass
