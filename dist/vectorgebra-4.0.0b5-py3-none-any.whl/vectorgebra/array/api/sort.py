from ..ndarray import Array

def argsort():
    pass

def sort():
    pass
