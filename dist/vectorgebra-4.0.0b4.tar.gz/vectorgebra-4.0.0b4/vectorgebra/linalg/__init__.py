"""
    This module contains more complex implementations for the Arrays
"""

from ..array import Array, Vector, Matrix

