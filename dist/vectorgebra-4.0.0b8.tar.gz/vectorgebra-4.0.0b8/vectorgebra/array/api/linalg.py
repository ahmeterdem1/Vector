"""
    Linear algebra extension of Array API referenced by: https://data-apis.org/array-api/latest/extensions/linear_algebra_functions.html
"""


def cholesky():
    pass

def cross():
    pass

def det():
    pass

def diagonal():
    pass

def eigh():
    pass

def eigvalsh():
    pass

def inv():
    pass

def matmul():
    pass

def matrix_norm():
    pass

def matrix_power():
    pass

def matrix_rank():
    pass

def matrix_transpose():
    pass

def outer():
    pass

def pinv():
    pass

def qr():
    pass

def slogdet():
    pass

def solve():
    pass

def svd():
    pass

def svdvals():
    pass

def tensordot():
    pass

def trace():
    pass

def vecdot():
    pass

def vector_norm():
    pass
